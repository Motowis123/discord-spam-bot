import pyautogui
from time import sleep

timer = 0
while timer != 10: # set 10 to how many seconds you want it to take before it starts
    timer += 1
    sleep(1)
    print("Spammer waiting... " + str(timer))

def spam(msg, maxMsg):
    count = 0
    while count != maxMsg:
        count += 1
        print("Send message: " + str(count))
        pyautogui.write(msg)
        pyautogui.press("enter")
        if count % 5 == 0 and count <= 15: # change 5 to 50 to make it type 50 msg
            sleep(5) # change to 0 to make it really fast

while True:
    spam("msg_here ", 10) #change 10 to 50 to make it type 50 msg
    # Sleep before sending more can be set to 0 but will not have any effect unless you change line 18 too
    sleep(5) # change to 0 to make it really fast   


#__  __    _    ____  _____   ______   __  __  __  ___ _____ _____        _____ ____  _ ____  _____ 
#|  \/  |  / \  |  _ \| ____| | __ ) \ / / |  \/  |/ _ \_   _/ _ \ \      / /_ _/ ___|/ |___ \|___ / 
#| |\/| | / _ \ | | | |  _|   |  _ \\ V /  | |\/| | | | || || | | \ \ /\ / / | |\___ \| | __) | |_ \ 
#| |  | |/ ___ \| |_| | |___  | |_) || |   | |  | | |_| || || |_| |\ V  V /  | | ___) | |/ __/ ___) |
#|_|  |_/_/   \_\____/|_____| |____/ |_|   |_|  |_|\___/ |_| \___/  \_/\_/  |___|____/|_|_____|____/ 