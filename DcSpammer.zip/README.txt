Discord spam bot
Spamms the discord page you are in remeber to click in the textbox in the server you want to spam.
Install pip if you havent by typing this in your cmd:
python get-pip.py
And intall pyautogui:
pip install pyautogui
Requires Python, install python here: https://www.python.org/ftp/python/3.12.4/python-3.12.4-amd64.exe
PASTE LINK IN BROWSER TO GET RIGHT VERSION

 __  __    _    ____  _____   ______   __  __  __  ___ _____ _____        _____ ____  _ ____  _____ 
 |  \/  |  / \  |  _ \| ____| | __ ) \ / / |  \/  |/ _ \_   _/ _ \ \      / /_ _/ ___|/ |___ \|___ / 
 | |\/| | / _ \ | | | |  _|   |  _ \\ V /  | |\/| | | | || || | | \ \ /\ / / | |\___ \| | __) | |_ \ 
 | |  | |/ ___ \| |_| | |___  | |_) || |   | |  | | |_| || || |_| |\ V  V /  | | ___) | |/ __/ ___) |
 |_|  |_/_/   \_\____/|_____| |____/ |_|   |_|  |_|\___/ |_| \___/  \_/\_/  |___|____/|_|_____|____/ 